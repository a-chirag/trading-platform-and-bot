package com.inautix.automation;

public class test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(TradingUtils.getOrderBookCurrentPrice("IndVsPak"));
	}

}
