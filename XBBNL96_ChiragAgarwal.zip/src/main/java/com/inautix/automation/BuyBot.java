package com.inautix.automation;

public class BuyBot extends TradeBot {
	static String side= "buy";
	public BuyBot(int user, String inst, double probs) {
		super(user, inst, probs, side);
		// TODO Auto-generated constructor stub
	}

}
