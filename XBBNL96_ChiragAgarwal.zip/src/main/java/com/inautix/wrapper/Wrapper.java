package com.inautix.wrapper;

public interface Wrapper {
public void setMetaData(MetaData metaData);
public void setData(Object data);
public void setError(BookError error);
}
