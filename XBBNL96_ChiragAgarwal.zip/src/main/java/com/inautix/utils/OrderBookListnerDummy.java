package com.inautix.utils;

public class OrderBookListnerDummy implements OrderBookListner {

}
