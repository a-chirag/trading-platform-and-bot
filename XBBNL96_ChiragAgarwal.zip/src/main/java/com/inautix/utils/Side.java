package com.inautix.utils;

public enum Side {
BUY,
SELL;
}
