package com.inautix.utils;

public interface Orderlistner {
public void add(Order o);
public void match(Order bo,Order so, Order o);
}
